# Finvera · Concept 02

Prepared 5 November 2026. This replaces the first design direction. Design artifacts only: no application UI, backend data, permissions or deployment has been changed. No implementation agents have been started.

[Open the interactive workspace](/workspace/artifacts/finvera-design-v2/index.html) · [Browse all pages](/workspace/artifacts/finvera-design-v2/all-pages.html)

## The visual direction

- Actual Finvera mark, taken from the current application.
- The existing Sora display and Inter text font families, embedded locally in every preview.
- The same Hugeicons line-icon family used by the application.
- The current #3e60ab → #243a75 blue gradient, rounded cards and soft blue canvas.
- Existing stage colours: planned blue, client-input amber, production peach, review pink, scheduled mint and published cyan.
- Readable page and card typography, stronger hierarchy and a more composed home layout.

## The sidebar

The first level is a compact workspace rail: Today, Social, Sales, Clients, Website and Admin. Each has an icon plus a text label. The second level shows the pages for the current space. This makes the full list easier to navigate without showing 27 equal-weight links at once.

- The blue rail icon marks the current space; the soft blue page row marks the exact page.
- A desktop collapse control reduces the sidebar to the rail. The current page remains identifiable through the breadcrumb.
- On phones the two levels become one combined slide-in drawer, with a backdrop and close behavior.
- Search reaches all accessible pages, including the eight website collections.
- The existing routes and role areas stay unchanged. The prototype role selector is a review tool, not a new product permission feature.
- Public website team and sign-in users have distinct labels. Website Portfolio is distinct from operational Renewals. Website stats are distinct from analytics.

## Page-by-page artifacts

| Page | Existing route | Interactive design | Desktop | Mobile |
|---|---|---|---|---|
| Overview | `/dashboard` | [Open](/workspace/artifacts/finvera-design-v2/pages/overview.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/overview.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/overview-mobile.png) |
| Content calendar | `/dashboard/social` | [Open](/workspace/artifacts/finvera-design-v2/pages/social.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/social.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/social-mobile.png) |
| Social studio | `/dashboard/social-studio` | [Open](/workspace/artifacts/finvera-design-v2/pages/social-studio.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/social-studio.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/social-studio-mobile.png) |
| Leads | `/dashboard/leads` | [Open](/workspace/artifacts/finvera-design-v2/pages/leads.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/leads.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/leads-mobile.png) |
| Contact inbox | `/dashboard/contact` | [Open](/workspace/artifacts/finvera-design-v2/pages/contact.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/contact.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/contact-mobile.png) |
| Renewals | `/dashboard/renewals` | [Open](/workspace/artifacts/finvera-design-v2/pages/renewals.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/renewals.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/renewals-mobile.png) |
| Website overview | `/dashboard/content` | [Open](/workspace/artifacts/finvera-design-v2/pages/content.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/content.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/content-mobile.png) |
| Portfolio | `/dashboard/projects` | [Open](/workspace/artifacts/finvera-design-v2/pages/projects.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/projects.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/projects-mobile.png) |
| Services | `/dashboard/services` | [Open](/workspace/artifacts/finvera-design-v2/pages/services.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/services.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/services-mobile.png) |
| Blog | `/dashboard/blog` | [Open](/workspace/artifacts/finvera-design-v2/pages/blog.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/blog.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/blog-mobile.png) |
| Website pages | `/dashboard/pages` | [Open](/workspace/artifacts/finvera-design-v2/pages/pages.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/pages.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/pages-mobile.png) |
| Website team | `/dashboard/team` | [Open](/workspace/artifacts/finvera-design-v2/pages/team.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/team.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/team-mobile.png) |
| Testimonials | `/dashboard/testimonials` | [Open](/workspace/artifacts/finvera-design-v2/pages/testimonials.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/testimonials.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/testimonials-mobile.png) |
| FAQs | `/dashboard/faqs` | [Open](/workspace/artifacts/finvera-design-v2/pages/faqs.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/faqs.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/faqs-mobile.png) |
| Values | `/dashboard/values` | [Open](/workspace/artifacts/finvera-design-v2/pages/values.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/values.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/values-mobile.png) |
| Brand ecosystem | `/dashboard/brands` | [Open](/workspace/artifacts/finvera-design-v2/pages/brands.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/brands.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/brands-mobile.png) |
| Company timeline | `/dashboard/timeline` | [Open](/workspace/artifacts/finvera-design-v2/pages/timeline.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/timeline.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/timeline-mobile.png) |
| Process steps | `/dashboard/process` | [Open](/workspace/artifacts/finvera-design-v2/pages/process.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/process.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/process-mobile.png) |
| Website stats | `/dashboard/stats` | [Open](/workspace/artifacts/finvera-design-v2/pages/stats.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/stats.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/stats-mobile.png) |
| Client logos | `/dashboard/logos` | [Open](/workspace/artifacts/finvera-design-v2/pages/logos.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/logos.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/logos-mobile.png) |
| Solution features | `/dashboard/features` | [Open](/workspace/artifacts/finvera-design-v2/pages/features.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/features.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/features-mobile.png) |
| SEO & sharing | `/dashboard/seo` | [Open](/workspace/artifacts/finvera-design-v2/pages/seo.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/seo.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/seo-mobile.png) |
| Users & access | `/dashboard/users` | [Open](/workspace/artifacts/finvera-design-v2/pages/users.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/users.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/users-mobile.png) |
| Activity log | `/dashboard/activity` | [Open](/workspace/artifacts/finvera-design-v2/pages/activity.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/activity.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/activity-mobile.png) |
| Settings & tracking | `/dashboard/settings` | [Open](/workspace/artifacts/finvera-design-v2/pages/settings.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/settings.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/settings-mobile.png) |
| System health | `/dashboard/system` | [Open](/workspace/artifacts/finvera-design-v2/pages/system.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/system.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/system-mobile.png) |
| My account | `/dashboard/account` | [Open](/workspace/artifacts/finvera-design-v2/pages/account.html) | [View](/workspace/artifacts/finvera-design-v2/screenshots/account.png) | [View](/workspace/artifacts/finvera-design-v2/screenshots/account-mobile.png) |

## Design notes by page

### Overview

A clear starting point for your day.

- Navigation: Workspace.
- Role-aware home: personal tasks for makers, cross-team priorities for admins.
- Urgent work first; business totals stay secondary.
- My work remains a view of the existing home/calendar, not a new backend module.

### Content calendar

Plan it, make it, review it, publish it.

- Navigation: Social media.
- One primary action per stage; Upload stays media-only.
- Client filter and view switch sit on one compact toolbar.
- Publishing results remain separate for Instagram and Facebook.
- Within-page sections: Board, Calendar, My work.

### Social studio

Your accounts, publishing results and performance.

- Navigation: Social media.
- Keep Analytics, Channels and Posts within the current route.
- Show the difference between connected, permission granted and tested.
- Instagram profile changes open Instagram; supported Facebook fields can be edited.
- Within-page sections: Analytics, Channels, Posts.

### Leads

Move the next conversation forward.

- Navigation: Sales.
- Follow-ups take visual priority over decorative totals.
- Board/list switch; lead detail uses Summary, Notes and Activity tabs.
- One next action per lead, with communication history alongside.
- Within-page sections: Pipeline, List.

### Contact inbox

Turn incoming messages into the right next step.

- Navigation: Sales.
- Three-pane inbox on desktop; stacked list/detail on mobile.
- Reply and Convert to lead remain distinct actions.
- Unread is a count; spam is a filter, not a competing main screen.
- Within-page sections: All, Unread, Spam.

### Renewals

Know what renews, who owns it and what is due.

- Navigation: Client operations.
- Rename the group from Projects to Client operations.
- Due dates and owner come before secondary financial detail.
- Renewal confirmation must retain the existing history.
- Within-page sections: All renewals, Due soon, History.

### Website overview

Everything that appears on the public website.

- Navigation: Website.
- This is the existing Site content hub with a clearer role in navigation.
- Expose all eight content collections through a nested Site sections group.
- Portfolio projects are website case studies, not delivery tasks.

### Portfolio

Show the work you want clients to discover.

- Navigation: Website.
- Rename Projects to Portfolio to remove operational ambiguity.
- Use visual cards with status and a short case-study title.
- Edit case-study content in a focused editor with live-site preview.

### Services

Keep your service offering clear and current.

- Navigation: Website.
- A compact ordered list is easier to maintain than large repeated cards.
- Description belongs in the editor, not every table row.

### Blog

Write, review and publish your ideas.

- Navigation: Website.
- Separate content writing from publishing metadata.
- Use a full writing surface; do not squeeze long articles into a narrow drawer.
- Show draft/published status next to the article title.
- Within-page sections: All articles, Drafts, Published.

### Website pages

Manage standalone page content and URLs.

- Navigation: Website.
- Rename Pages to Website pages so the navigation purpose is explicit.
- Show the slug and a safe preview affordance alongside the title.

### Website team

The people shown on your public website.

- Navigation: Website.
- Rename Team to Website team.
- This manages public bios; Users & access manages login permissions.

### Testimonials

Let client experiences speak clearly.

- Navigation: Website.
- Preview the quote card and keep editing fields beside it.
- Ratings and publication state stay separate.

### FAQs

Questions visitors ask most.

- Navigation: Website.
- Public placement: Home page.
- Use an ordered collection with a contextual preview, not another large dashboard.
- Reachable from Website → Site sections, search and the Website overview.

### Values

The principles behind your public story.

- Navigation: Website.
- Public placement: About page.
- Use an ordered collection with a contextual preview, not another large dashboard.
- Reachable from Website → Site sections, search and the Website overview.

### Brand ecosystem

Brands in the Finvera ecosystem.

- Navigation: Website.
- Public placement: About page.
- Use an ordered collection with a contextual preview, not another large dashboard.
- Reachable from Website → Site sections, search and the Website overview.

### Company timeline

The milestones behind the business.

- Navigation: Website.
- Public placement: About page.
- Use an ordered collection with a contextual preview, not another large dashboard.
- Reachable from Website → Site sections, search and the Website overview.

### Process steps

Explain how working together feels.

- Navigation: Website.
- Public placement: Home & Services.
- Use an ordered collection with a contextual preview, not another large dashboard.
- Reachable from Website → Site sections, search and the Website overview.

### Website stats

The numbers displayed on your website.

- Navigation: Website.
- Public placement: Home page.
- Use an ordered collection with a contextual preview, not another large dashboard.
- Reachable from Website → Site sections, search and the Website overview.

### Client logos

The trusted-by logos on your website.

- Navigation: Website.
- Public placement: Home page.
- Use an ordered collection with a contextual preview, not another large dashboard.
- Reachable from Website → Site sections, search and the Website overview.

### Solution features

The benefits shown in your solutions section.

- Navigation: Website.
- Public placement: Home page.
- Use an ordered collection with a contextual preview, not another large dashboard.
- Reachable from Website → Site sections, search and the Website overview.

### SEO & sharing

Control how each website page appears in search and social.

- Navigation: Website.
- Group SEO with website work, while preserving the SEO role gate.
- Show search and social previews beside metadata fields.
- A preview is illustrative, not a promise of search-engine appearance.

### Users & access

Manage who can sign in and what they can do.

- Navigation: Administration.
- Keep authentication users clearly separate from Website team.
- Access, invitations and security events have distinct tabs.
- Role previews must not grant access or replace backend checks.
- Within-page sections: People, Invitations, Security log.

### Activity log

A readable history of who changed what.

- Navigation: Administration.
- Read-only audit trail; do not add a fake create/edit action.
- Filters for person, entity, action and date sit above one chronological list.

### Settings & tracking

Website configuration and measurement in one place.

- Navigation: Administration.
- Retain General, Social links and Analytics & pixels settings.
- Keep account connections in Social studio and infrastructure in System.
- One save bar with unsaved-state feedback; no repeated save buttons.
- Within-page sections: General, Social links, Analytics & pixels.

### System health

Know what is healthy and what needs attention.

- Navigation: Administration.
- Health cards for database, email, backups and scheduled jobs.
- Meta account issues link to Social studio instead of duplicating its controls.
- Show last checked time and distinguish unknown from healthy.
- Within-page sections: Health, Backups, Scheduled jobs.

### My account

Your profile, sign-in security and preferences.

- Navigation: Personal.
- Pin My account in the sidebar footer, outside business navigation.
- Preserve all six account sections.
- Show security actions in their own section, away from routine profile edits.
- Within-page sections: Profile, Password, Two-step login, Devices, Emails, Activity.

## Scope and review

Every record, number, chart and account state is illustrative. Prototype create/edit buttons open local forms or previews. No API, Meta publishing, email, login or backend mutation runs from these files. Fonts and icons are included locally; the prototype requires no remote requests.

Review the sidebar direction first, then the core page compositions and individual collections. After your explicit approval, implementation agents can update only the approved UI, preserving the current backend contracts and workflow safeguards. No agents are started before approval.

The website editor, social workflow, sales workspace and administration pages should retain their own layouts while sharing this Finvera shell and visual language. The eight small content collections intentionally share a consistent collection editor pattern.

## Validation

All 27 desktop and all 27 phone-sized previews passed browser checks. Checks also covered the embedded Sora fonts, one active page, collapsed rail, role-filtered navigation and search, upload-only handoff, review and read-only security records. No remote requests were made. These are prototype checks, not production application tests.

[Sidebar close-up](/workspace/artifacts/finvera-design-v2/screenshots/sidebar-expanded.png) · [Mobile navigation](/workspace/artifacts/finvera-design-v2/screenshots/sidebar-mobile.png) · [PDF design book](/workspace/artifacts/finvera-design-v2/Finvera-Concept-02-Design-Book.pdf)
